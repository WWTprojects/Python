# Write a program to help with taxes
#Should accept an input of income
# Should accept input of marital status (Single/married)
# Should accept inout of elevation of users home address (below/at/above sea level)
# Should produce the amount of income tax owed for that year as the output


# Get user inputs
print("Hi! I'm here to help you see how much income tax you owe!")
print("To start off, input how much income you made this past year")
income = float(input())
print("Now what is your marital status (single/married)")
maritalStatus = input()
print("Okay, now whats the current elevation of your home in reference to sea level (below/at/above)")
elevation = input()

# Create function to calculate income tax
def yearly_income(a):
    if (a < 10000):
        return .023
    elif ((a >= 10000) & (a <= 50000)):
        return .045
    else:
        return .061

# Create function to make changes to yearly income after the previous function happened
def marital_status(incomeTax, maritalStatus):
    if (maritalStatus == "married"):
        incomeTax = (incomeTax - 24.62)
        return incomeTax
    elif (maritalStatus == "single"):
        incomeTax = incomeTax
        return incomeTax
    else:
        print("wasn't a valid input homie")

# Create function for what happens depending on the answer for elevation
def current_elevation(incomeTax, height):
    if (height == "below"):
        return (incomeTax + 18.32)
    elif ((height == "at") or (height == "above")):
        return incomeTax
    else:
        print("not valid in regards to")


#Create the outputs, having a list of what they put and then what the imapct of each choice did for their income tax toal.
print("Okay, so your income is", income, ", your marital status was", maritalStatus, ", and your address is", elevation, "sea level.")
print()
print("After factoring in your income, your current income tax becomes", yearly_income(income)*income,
      "since your income warrents a", yearly_income(income)*100,"% income tax.")
incomeTax = yearly_income(income)*income
print("Factoring in your marital status, your income tax now becomes", marital_status(incomeTax, maritalStatus),
      "since being married warrants a $24.62 decrease in income tax, while being single does nothing to it.")
incomeTax = marital_status(incomeTax, maritalStatus)
print("Finally, after factoring in your home address' elevaton, your income tax totals "
      "to", current_elevation(incomeTax, elevation), "as a result of elevation only increasing your income tax "
      "if you are below sea level, by $18.32.")
