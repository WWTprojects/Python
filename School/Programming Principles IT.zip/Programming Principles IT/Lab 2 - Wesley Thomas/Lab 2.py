
# Write a program that asks the user to enter their name (First and last name), and the number of books that he or she
# has purchased this month and displays their name and the number of points they have earned for the month. Your program
# may run once per user, or may loop to accept multiple users.

# Wesley Thomas

#Take in how many iterations the loop needs to go for
print("How many people do you want to run this program for?")
numberOfPeople = int(input())   #Makes sure the input is read as an Integer

#Create emtpy lists to have the user input go in to so that it can be referenced
name = []    #Empty List for the names
books = []   #Empty List for the number of books entered for the person

#Get the inputs needed and assign them to indexes in the empty loops created above
for i in range(0, (numberOfPeople)):
    print("Enter first and last name of person", i+1)
    nameIndex = input()
    name.append(nameIndex)   #Function of lists that add that value into the empty list created earlier
    print("Enter number of books for person", i+1)
    booksIndex = int(input())
    books.append(booksIndex)   #Function of lists that add that value into the empty list created earlier

#Creating the output conditions based on the data referenced from each particular index of the lists created above
for i in range(0, (numberOfPeople)):   #Range function to say when to start and end for iterations
    if(books[i] < 0):
        print("This is not a valid input")
    elif(books[i] == 0):
        print(name[i], books[i], "books", "0 points")
    elif(books[i] <= 3):
        print(name[i], books[i], "books", "5 Points")
    elif(books[i] <= 6):
        print(name[i], books[i], "books", "10 Points")
    elif(books[i] <= 8):
        print(name[i], books[i], "books", "15 Points")
    elif(books[i] == 9):
        print(name[i], books[i], "books", "20 Points")
    else:
        print(name[i], books[i], "books", "25 Points")
print()
print("Thanks for the Data!")