# Wesley Thomas
# Get user input for 8 assignment scores for 12 students
# Program should output student name, letter grade for each score, and cumulative average per person for all the
# assignments
# Have a calc_average function
# Have a determine_grade function

def calc_average(grades):  # Takes the grades and takes the average of them
    sum = 0
    for i in grades:
        sum = sum + i
    avg = sum / len(grades)
    return avg


# function for determining grade for given marks
def determine_grade(grades):
    if (grades >= 90):
        return 'A'
    elif (grades >= 80):
        return 'B'
    elif (grades >= 70):
        return 'C'
    elif (grades >= 60):
        return 'D'
    else:
        return 'F'

n = 12  # used for number of students
for i in range(1, n + 1):
    name = input("Enter the name of the student: ")
    print("Enter the 8 grades of the student separated by a space for each one :")
    array = list(map(int, input().split(" ")))  # used to make a space between the grades
                                              # map will mack each spliited input into an integer
    avg = calc_average(array)
    print(name)
    for k in array:
        grade = determine_grade(k)
        print(k, " ", grade)
    print("The average grade for", name, "is", avg)