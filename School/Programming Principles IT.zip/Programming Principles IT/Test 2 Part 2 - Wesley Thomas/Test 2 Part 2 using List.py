# Write a program that takes user input for kilometer to miles conversion or miles to kilometers
# Write two functions that each  accept a distance as an argument, one that converts from Miles-to-Kilometers, and
# one that converts from Kilometers-to-Miles.
def KilometersToMiles(a):
    newMiles = (a * 0.6214)
    return newMiles
def MilesToKilometers(a):
    newKilometers = (a / 0.6214)
    return newKilometers
distances = []
print("Welcome to the distance conversion program!")
print("This program converts Kilometers to Miles, and Miles to Kilometers.")
print("How many distances are you looking to convert?")
length = int(input())
for i in range(0, length):
    check = 1
    while (check == 1):
        print("Is this distance going to be miles or kilometers? km/m")
        choice = input()
        if (choice == "m"):
            print("Great! Please input the distance in miles (No units):")
            convertToKilometers = float(input())
            distances.insert(i, ('Miles:', convertToKilometers, '    Kilometers:', KilometersToMiles(convertToKilometers)))
            check = 0
        elif (choice == "km"):
            print("Great! Please input the distance in kilometers (No need for units):")
            convertToMiles = float(input())
            distances.insert(i, ('Kilometers:', convertToMiles, 'Miles:', MilesToKilometers(convertToMiles)))
            check = 0
        else:
            print("Sorry that wasn't a valid input, please try again")
for j in range(0, length):
    print(distances[j])
