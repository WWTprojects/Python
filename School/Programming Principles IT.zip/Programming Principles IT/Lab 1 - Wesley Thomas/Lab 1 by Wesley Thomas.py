# Wesley Thomas
# Lab 1

#Declare variables for grocery item
item1 = ""
item2 = ""
item3 = ""
item4 = ""
item5 = ""
item6 = ""
item7 = ""
item8 = ""

#Declare variable
# s for the price for each item
price1 = 0.0
price2 = 0.0
price3 = 0.0
price4 = 0.0
price5 = 0.0
price6 = 0.0
price7 = 0.0
price8 = 0.0

#Ask for inputs for the groceries and their price using the variables above
print("Type in the 1st grocery item: ")
item1 = input()
print("Type in the 1st grocery item's price: ")
price1 = input()
print("Type in the 2nd grocery item: ")
item2 = input()
print("Type in the 2nd grocery item's price: ")
price2 = input()
print("Type in the 3rd grocery item: ")
item3 = input()
print("Type in the 3rd grocery item's price: ")
price3 = input()
print("Type in the 4th grocery item: ")
item4 = input()
print("Type in the 4th grocery item's price: ")
price4 = input()
print("Type in the 5th grocery item: ")
item5 = input()
print("Type in the 5th grocery item's price: ")
price5 = input()
print("Type in the 6th grocery item: ")
item6 = input()
print("Type in the 6th grocery item's price: ")
price6 = input()
print("Type in the 7th grocery item: ")
item7 = input()
print("Type in the 7th grocery item's price: ")
price7 = input()
print("Type in the 8th grocery item: ")
item8 = input()
print("Type in the 8th grocery item's price: ")
price8 = input()

#Print out the list
print("Below is your list of groceries and their respective prices")
print(item1,"    ",price1)
print(item2,"    ",price2)
print(item3,"    ",price3)
print(item4,"    ",price4)
print(item5,"    ",price5)
print(item6,"    ",price6)
print(item7,"    ",price7)
print(item8,"    ",price8)
