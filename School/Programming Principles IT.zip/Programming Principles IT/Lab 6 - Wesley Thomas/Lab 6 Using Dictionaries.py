# Wesley Thomas
# Write a program that allows the user to enter the total rainfall for each of 12 months into an array.
# The program should then calculate the following metrics from the array:
# The total rainfall for the year
# The average monthly rainfall
# The month with the highest rainfall amount
# The month with the lowest rainfall amount

rainfall = {}

for i in range(0,12):
    print("Enter the month that you would like to enter the rainfall for:")
    month = input()
    print("Enter the rainfall for that month")
    count = float(input())
    rainfall[month] = count

print(rainfall)

print("The total rainfall for the year is", sum(rainfall.values()))
print("The average monthly rainfall for the year is", (sum(rainfall.values())/12))
print("The month with the highest rainfall amount is", max(rainfall, key = rainfall.get))
print("The month with the lowest rainfall amount is", min(rainfall, key = rainfall.get))
