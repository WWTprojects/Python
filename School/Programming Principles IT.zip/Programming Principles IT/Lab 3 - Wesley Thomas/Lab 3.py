# Wesley Thomas

# This program is intended to calculate the cost of tuition for 2019 and the next 7 years following it, with the
# starting tuition in 2019 being $7180. The rate it increases per year is 3.5% and we were instructed to use a loop
# in order to have it output the year and the corresponding cost of tuition out to the side, all the while not resulting
# to hard coding for our outputs (effectively you can get more years past the requested by simply changing the end i
# value at the start of the loop.

# To do this program, first you need to have the starting tuition, the amount of years you want, and the starting year
# Then, you need to make a for loop that which will run for the next 7 iterations.
# Within the iterations, it needs to add 1 to the year and also use the previous cost of tuition in order to make the
# new one by multiplying the previous tuition cost by the rate (.035), and then adding that value to the tuition cost of
# the previous year.

# for formatting the cost into an actual cent value (rounding to the 2nd decimal place), I had to look online and found
# the {:0.2f} and .format() function

startingTuition = 7180
years = 7
startingYear = 2019
print("Below, you can see the cost tuition to attend this school for 2019 and the 7 years following.")
print(startingYear, "    ${:0.2f}" .format(startingTuition)) #{:0.2f} and the .format make it round to 2 decimal places
tuition = startingTuition   #This is keeping the variable 'tuition' as the constant variable used for calculations
for i in range (1, (years+1)):   #Sets 'i' to start as one and going up to (years + 1), which makes 7 iterations
    tuitionYear = (2019 + i)   #Allows the program to display an increasing year based on which iteration it is
    rate = .035   #The rate of 3.5% converted as a decimal for calculation purposes
    projectedTuition = tuition + (tuition * rate)   #Getting the desired end tuition for that year
    print(tuitionYear, "    ${:0.2f}" .format(projectedTuition))   #Printing out what we want
    tuition = projectedTuition   #Makes current iteration tuition cost be the referenced tuition for the next iteration
