# Write a program to allow the user to play rock, paper, scissors against the computer.

# Get users choice
#   Prompt user( with instructions)
#   Read in selection

# Get computer Choice
#     random.randint(a, b)
#     Return a random integer N such that a <= N <= b.Alias for randrange(a, b + 1).
#    Pick a random number
#    Convert to equivalent String
# Define Rules(Determine Winner)
#    *Rock beats scissors
#    *Scissors beats paper
#    *Paper beats rock
#    *If same, then tie
# Internal Representation:
# Rock == “rock”
# Paper == “paper”
# Scissors == “scissors”

from random import randint
again = 'y'

while again == 'y':
    # Get user's choice
    print("Please select 'rock', 'paper', or 'scissors'")
    user_choice = input()

    rand_number = randint(1, 3)
    computer_choice = ""
    if rand_number == 1:
        computer_choice = "rock"
    elif rand_number == 2:
        computer_choice = "paper"
    elif rand_number == 3:
        computer_choice = "scissors"
    else:
        print("Random number error, PANIC!")
        quit()

    if computer_choice == user_choice:
        print("Its a Tie!")
    else:
        if user_choice == "paper" and computer_choice == "rock":
            print("Paper covers rock, you win!")
        elif user_choice == "paper" and computer_choice == "scissors":
            print("Scissors cut paper, you loose... Ha Ha!")
        elif user_choice == "rock" and computer_choice == "paper":
            print("Paper covers rock, you loose!")
        elif user_choice == "rock" and computer_choice == "scissors":
            print("Rock Breaks Scissors, You win!")

    print("Do you want to play again [y/n]: ")
    again = input()
