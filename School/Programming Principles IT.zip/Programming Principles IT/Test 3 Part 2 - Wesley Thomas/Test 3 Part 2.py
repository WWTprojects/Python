# Wesley Thomas

# At certain Olympic events, there are 5 judges.  To determine an athlete’s final score for the event, the highest
# and lowest judges’ scores are discarded and then the average of the rest of the scores is calculated.
# Assume that the array 'Scores' contains the judges’ scores. Write a function that accepts as an argument a list of
# scores and returns the athlete’s final score.

def finalScore(variable): #Create function to accept the list
    average = ((sum(variable) - min(variable)- max(variable))/(len(variable)-2)) #Calculation to get final score
    return average #Return the value desired so it can be displayed when called

scores = [] #Create empty list

for i in range(0,5): #Loop to get 5 inputs
    print("Enter the score of judge", (i+1))
    value = float(input()) #Ensures all values are taken as decimals
    scores.append(value) #Adds inputs to the empty list defined earlier

print("The sum of the judges scores is", sum(scores)) #Showcase the original total of the scores
print("The minimum score of the judges is", min(scores)) #Point out the minimum value
print("The maxmimum score of the judges is", max(scores)) #Point out the maximum value
print("Final Score: ", finalScore(scores)) #Give final score by having list ran through the finalScore function