
#Prompt the user to enter the count of players.

print("Enter the number of people you want to run for this program")
num = int(input())
#Open the file in write mode.
f = open("golf.tx", "w")
for i in range(num):
    #Prompt the user to enter the name.
    print ("Enter name of player", i+1 ,":",end="");
    player_name = input()
    #Prompt the user to enter the score.
    print ("Enter score of player", i+1 ,":",end="");
    player_score = input()
    #Write the name and score for the txt file
    f.write(player_name)
    f.write('\n')
    f.write(player_score)
    f.write('\n')
#Close the file.
f.close();