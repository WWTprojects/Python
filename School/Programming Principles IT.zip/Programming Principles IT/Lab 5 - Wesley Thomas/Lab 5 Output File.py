#Open the file in the read mode.
fopen = open("golf.tx", "r")
#Display the statement.
print("The data in the golf.txt file is as follows:");
#Befin the loop.
for i in fopen:
    #Display the data.
    print(i,end="")